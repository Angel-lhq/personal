package dongzhong.testforfloatingwindow;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.net.http.SslError;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.support.annotation.Nullable;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.PermissionRequest;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;

/**
 * Created by dongzhong on 2018/5/30.
 */

public class FloatingButtonService extends Service {
    public static boolean isStarted = false;

    private WindowManager windowManager;
    private WindowManager.LayoutParams layoutParams;

    private Button button;

    private WebView webView;

    @Override
    public void onCreate() {
        super.onCreate();
        isStarted = true;
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        layoutParams = new WindowManager.LayoutParams();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            layoutParams.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            layoutParams.type = WindowManager.LayoutParams.TYPE_PHONE;
        }
        layoutParams.format = PixelFormat.RGBA_8888;
        layoutParams.gravity = Gravity.LEFT | Gravity.TOP;
        layoutParams.flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        layoutParams.width = 600;
        layoutParams.height = 600;
        layoutParams.x = 0;
        layoutParams.y = 0;
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        showFloatingWindow();
        return super.onStartCommand(intent, flags, startId);
    }

    @SuppressLint("JavascriptInterface")
    private void showFloatingWindow() {
        if (Settings.canDrawOverlays(this)) {
//            button = new Button(getApplicationContext());
//            button.setText("Floating Window");
//            button.setBackgroundColor(Color.BLUE);
            View floatView = LayoutInflater.from(getApplicationContext()).inflate(R.layout.floating_view, null);

            ImageView imageView = floatView.findViewById(R.id.img);
            webView = new WebView(getApplicationContext());
            webView.setWebViewClient(new UnSafeWebViewClient());
            webView.setWebChromeClient(new UnSafeChromeClient());

            WebSettings wsTmp = webView.getSettings();
            wsTmp.setJavaScriptEnabled(true);
            wsTmp.setJavaScriptCanOpenWindowsAutomatically(true);
            wsTmp.setDomStorageEnabled(true);
            wsTmp.setGeolocationEnabled(true);
            wsTmp.setLoadsImagesAutomatically(true);
            wsTmp.setUseWideViewPort(true);
            wsTmp.setLoadWithOverviewMode(true);
            wsTmp.setLayoutAlgorithm(WebSettings.LayoutAlgorithm.SINGLE_COLUMN);
            wsTmp.setDatabaseEnabled(true);
            wsTmp.setMediaPlaybackRequiresUserGesture(false);
            wsTmp.setDefaultTextEncodingName("utf-8");
            wsTmp.setCacheMode(WebSettings.LOAD_DEFAULT);
            webView.setBackgroundColor(getResources().getColor(R.color.colorAccent));
            webView.addJavascriptInterface(this, "mediaAndroid");
//            webView.setVisibility(View.INVISIBLE);
            windowManager.addView(webView, layoutParams);

            imageView.setImageResource(R.mipmap.ic_launcher);
            webView.loadUrl("https://www.baidu.com");

            webView.setOnTouchListener(new FloatingOnTouchListener());
            webView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                }
            });
        }
    }

    public class UnSafeWebViewClient extends WebViewClient {

        @Nullable
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            return super.shouldInterceptRequest(view, request);
        }

        @Override
        public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
            handler.proceed();
            super.onReceivedSslError(view, handler, error);
        }
    }

    public class UnSafeChromeClient extends WebChromeClient {

        @Override
        public void onPermissionRequest(final PermissionRequest request) {
            super.onPermissionRequest(request);
        }
    }

    private class FloatingOnTouchListener implements View.OnTouchListener {
        private int x;
        private int y;

        @Override
        public boolean onTouch(View view, MotionEvent event) {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    x = (int) event.getRawX();
                    y = (int) event.getRawY();
                    break;
                case MotionEvent.ACTION_MOVE:
                    int nowX = (int) event.getRawX();
                    int nowY = (int) event.getRawY();
                    int movedX = nowX - x;
                    int movedY = nowY - y;
                    x = nowX;
                    y = nowY;
                    layoutParams.x = layoutParams.x + movedX;
                    layoutParams.y = layoutParams.y + movedY;
                    windowManager.updateViewLayout(view, layoutParams);
                    break;
                default:
                    break;
            }
            return true;
        }
    }
}
