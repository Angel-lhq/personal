# FloatWindow
A project show how to add float window in Android.

In this project, you will find a more elegant way to use float window.
Especially, if you are struggling with special ROM.🙃

More details will found in: https://www.jianshu.com/p/3246f7289704 (Chinese Only)
