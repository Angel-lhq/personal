# FloatingWindowDemo <a href="https://blog.csdn.net/lzw398756924/article/details/106012948" rel="nofollow">博客地址</a>
悬浮窗功能实现帮助类，微信语音通话悬浮窗效果实现Demo
<h6>显示效果</h6>
<img src="https://img-blog.csdnimg.cn/20200511151213525.gif" />
<img src="https://img-blog.csdnimg.cn/20200511145025431.gif" />
